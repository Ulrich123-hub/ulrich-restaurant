# Ulrich Restaurant Website

GitHub-ready starter website for Ulrich Restaurant.

## Location
Cité de la Paix, Dernière Barrière, Yaoundé, Cameroon.

## Files
- `index.html` — main website
- `images/` — website images

Replace the placeholder images in `images/` with your real restaurant photos while keeping the same filenames, or update the image paths in `index.html`.

## GitHub Pages
Upload the contents of this folder to a GitHub repository. GitHub Pages can then publish `index.html` as the website homepage.
